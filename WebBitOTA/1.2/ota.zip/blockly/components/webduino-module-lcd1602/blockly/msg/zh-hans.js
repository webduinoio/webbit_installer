MSG.catLCD1602 = "LCD 点阵屏幕";
