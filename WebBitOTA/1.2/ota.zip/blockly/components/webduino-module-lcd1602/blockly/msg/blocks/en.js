// LCD1602
Blockly.Msg.WEBDUINO_LCD1602 = "LCD (1602)，SDA ";
Blockly.Msg.WEBDUINO_LCD1602_SCL = " SCL";
Blockly.Msg.WEBDUINO_LCD1602_ADDR = "  Address"
Blockly.Msg.WEBDUINO_LCD1602_PRINT = "Print:";
Blockly.Msg.WEBDUINO_LCD1602_CLEAR = "Clear Screen";
Blockly.Msg.WEBDUINO_LCD1602_START = "Text start position:";
Blockly.Msg.WEBDUINO_LCD1602_ROW = "Row";
Blockly.Msg.WEBDUINO_LCD1602_COLUMN = "Column";
