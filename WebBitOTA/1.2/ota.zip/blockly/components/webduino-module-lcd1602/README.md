# webduino-module-lcd1602

Webduino Module for LCD1602.

LCD1602 is a character type liquid crystal display, which can display 32 (16*2) characters at
the same time.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-module-lcd1602.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
