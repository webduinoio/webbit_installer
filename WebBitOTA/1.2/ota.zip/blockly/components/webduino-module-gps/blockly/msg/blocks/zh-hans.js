// GPS
Blockly.Msg.WEBDUINO_GPS_RX = "GPS 定位(TinyGPS)，RX ";
Blockly.Msg.WEBDUINO_GPS_TX = "  TX";
Blockly.Msg.WEBDUINO_GPS_LOCATE = "经纬度:";
Blockly.Msg.WEBDUINO_GPS_TIME = "目前时间:";
Blockly.Msg.WEBDUINO_GPS_GET_NOW = "取得资讯:";
Blockly.Msg.WEBDUINO_GPS_GET_CORD = "取得经纬度和时间";
Blockly.Msg.WEBDUINO_GPS_EVERY = "，每";
Blockly.Msg.WEBDUINO_GPS_RUN_EVERY_MS = "毫秒执行一次";
Blockly.Msg.WEBDUINO_GPS_DO = "执行";
Blockly.Msg.WEBDUINO_GPS_CURRENT_VALUE = "所测得目前的";
Blockly.Msg.WEBDUINO_GPS_CURRENT_LATITUDE = "纬度";
Blockly.Msg.WEBDUINO_GPS_CURRENT_LONGITUDE = "经度";
Blockly.Msg.WEBDUINO_GPS_CURRENT_DATE = "日期";
Blockly.Msg.WEBDUINO_GPS_CURRENT_TIME = "时间";