// GPS
Blockly.Msg.WEBDUINO_GPS_RX = "GPS (TinyGPS), RX ";
Blockly.Msg.WEBDUINO_GPS_TX = "  TX";
Blockly.Msg.WEBDUINO_GPS_LOCATE = "Location:";
Blockly.Msg.WEBDUINO_GPS_TIME = "Time:";
Blockly.Msg.WEBDUINO_GPS_GET_NOW = "Read Info:";
Blockly.Msg.WEBDUINO_GPS_GET_CORD = "Get Coordinate with Time";
Blockly.Msg.WEBDUINO_GPS_EVERY = "run every";
Blockly.Msg.WEBDUINO_GPS_RUN_EVERY_MS = "Millisecond";
Blockly.Msg.WEBDUINO_GPS_DO = "Do";
Blockly.Msg.WEBDUINO_GPS_CURRENT_VALUE = "Current Value of";
Blockly.Msg.WEBDUINO_GPS_CURRENT_LATITUDE = "Latitude";
Blockly.Msg.WEBDUINO_GPS_CURRENT_LONGITUDE = "Longtitude";
Blockly.Msg.WEBDUINO_GPS_CURRENT_DATE = "Date";
Blockly.Msg.WEBDUINO_GPS_CURRENT_TIME = "Time";