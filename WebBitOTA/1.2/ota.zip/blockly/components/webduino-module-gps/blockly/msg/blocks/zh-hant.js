// GPS
Blockly.Msg.WEBDUINO_GPS_RX = "GPS 定位 ( TinyGPS )，RX ";
Blockly.Msg.WEBDUINO_GPS_TX = " TX";
Blockly.Msg.WEBDUINO_GPS_LOCATE = "經緯度:";
Blockly.Msg.WEBDUINO_GPS_TIME = "目前時間:";
Blockly.Msg.WEBDUINO_GPS_GET_NOW = "取得資訊:";
Blockly.Msg.WEBDUINO_GPS_GET_CORD = "取得經緯度和時間";
Blockly.Msg.WEBDUINO_GPS_EVERY = "，每";
Blockly.Msg.WEBDUINO_GPS_RUN_EVERY_MS = "毫秒執行一次";
Blockly.Msg.WEBDUINO_GPS_DO = "執行";
Blockly.Msg.WEBDUINO_GPS_CURRENT_VALUE = "所測得目前的";
Blockly.Msg.WEBDUINO_GPS_CURRENT_LATITUDE = "緯度";
Blockly.Msg.WEBDUINO_GPS_CURRENT_LONGITUDE = "經度";
Blockly.Msg.WEBDUINO_GPS_CURRENT_DATE = "日期";
Blockly.Msg.WEBDUINO_GPS_CURRENT_TIME = "時間";