# webduino-bit-module-sound

Module for Webduino:bit Sound.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-bit-module-sound.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
