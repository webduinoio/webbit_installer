Blockly.Msg.WEBDUINO_SOUND = "声音侦测传感器，脚位";
Blockly.Msg.WEBDUINO_SOUND_WHEN = "当";
Blockly.Msg.WEBDUINO_SOUND_STATUS_DETECTED = "有";
Blockly.Msg.WEBDUINO_SOUND_STATUS_ENDED = "没有";
Blockly.Msg.WEBDUINO_SOUND_DETECTED = "侦测到声音变化";
Blockly.Msg.WEBDUINO_SOUND_DO = "执行";
