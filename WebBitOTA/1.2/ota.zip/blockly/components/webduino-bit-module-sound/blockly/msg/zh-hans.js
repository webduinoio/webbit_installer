MSG.catSound = "声音侦测";
