Blockly.Msg.WEBDUINO_SOUND = "聲音偵測傳感器，腳位";
Blockly.Msg.WEBDUINO_SOUND_WHEN = "當";
Blockly.Msg.WEBDUINO_SOUND_STATUS_DETECTED = "有";
Blockly.Msg.WEBDUINO_SOUND_STATUS_ENDED = "沒有";
Blockly.Msg.WEBDUINO_SOUND_DETECTED = "偵測到聲音變化";
Blockly.Msg.WEBDUINO_SOUND_DO = "執行";
