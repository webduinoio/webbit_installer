MSG.catSound = "聲音偵測"; 
