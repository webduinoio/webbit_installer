Blockly.Msg.WEBDUINO_SOUND = "Sound Sensor, Pin:";
Blockly.Msg.WEBDUINO_SOUND_WHEN = "When";
Blockly.Msg.WEBDUINO_SOUND_STATUS_DETECTED = "Detected";
Blockly.Msg.WEBDUINO_SOUND_STATUS_ENDED = "not Detected";
Blockly.Msg.WEBDUINO_SOUND_DETECTED = "Sound's Change";
Blockly.Msg.WEBDUINO_SOUND_DO = "Do";
