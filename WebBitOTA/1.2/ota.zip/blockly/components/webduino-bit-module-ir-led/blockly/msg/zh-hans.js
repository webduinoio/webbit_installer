catIRLed = "红外线发射";
