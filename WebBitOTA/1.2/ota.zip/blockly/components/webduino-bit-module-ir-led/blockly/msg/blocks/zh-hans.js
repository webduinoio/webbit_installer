Blockly.Msg.WEBDUINO_IRLED = "红外线发射，脚位";
Blockly.Msg.WEBDUINO_IRLED_LAUNCHCODE = "发射代码 ( 十六进位 )";
