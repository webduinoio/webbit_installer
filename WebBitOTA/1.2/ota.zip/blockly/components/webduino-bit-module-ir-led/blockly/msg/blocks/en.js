Blockly.Msg.WEBDUINO_IRLED = "IR launch, Pin:";
Blockly.Msg.WEBDUINO_IRLED_LAUNCHCODE = "Launch Codes (m-16):";
