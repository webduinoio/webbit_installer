catIRLed = "紅外線發射";
