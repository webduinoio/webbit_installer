Blockly.Msg.WEBDUINO_IRLED = "紅外線發射，腳位";
Blockly.Msg.WEBDUINO_IRLED_LAUNCHCODE = "發射代碼 ( 十六進位 )";
