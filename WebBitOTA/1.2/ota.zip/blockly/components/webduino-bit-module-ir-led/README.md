# webduino-bit-module-ir-led

Module for IR LED of Webduino:bit.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-bit-module-ir-led.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
