catIRRecv = "红外线接收";
