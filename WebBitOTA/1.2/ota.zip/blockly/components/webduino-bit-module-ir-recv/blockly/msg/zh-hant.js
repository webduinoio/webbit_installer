catIRRecv = "紅外線接收";
