Blockly.Msg.WEBDUINO_IRRECV = "红外线接收，脚位";
Blockly.Msg.WEBDUINO_IRRECV_ON = "开始接收";
Blockly.Msg.WEBDUINO_IRRECV_CODE = "接收的代码";
Blockly.Msg.WEBDUINO_IRRECV_OFF = "停止接收";
Blockly.Msg.WEBDUINO_IRRECV_DO = "执行";
