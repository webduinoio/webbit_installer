Blockly.Msg.WEBDUINO_IRRECV = "紅外線接收，腳位";
Blockly.Msg.WEBDUINO_IRRECV_ON = "開始接收";
Blockly.Msg.WEBDUINO_IRRECV_CODE = "接收的代碼";
Blockly.Msg.WEBDUINO_IRRECV_OFF = "停止接收";
Blockly.Msg.WEBDUINO_IRRECV_DO = "執行";
