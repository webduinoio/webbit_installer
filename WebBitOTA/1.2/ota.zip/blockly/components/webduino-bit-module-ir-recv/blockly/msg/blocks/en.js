Blockly.Msg.WEBDUINO_IRRECV = "IR Receiver, Pin:";
Blockly.Msg.WEBDUINO_IRRECV_ON = "Start Receiving";
Blockly.Msg.WEBDUINO_IRRECV_CODE = "Received Code";
Blockly.Msg.WEBDUINO_IRRECV_OFF = "Stop Receiving";
Blockly.Msg.WEBDUINO_IRRECV_DO = "Do";
