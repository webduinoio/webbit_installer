MSG.catButton = "按钮开关";
