MSG.catButton = "Button Switch";
