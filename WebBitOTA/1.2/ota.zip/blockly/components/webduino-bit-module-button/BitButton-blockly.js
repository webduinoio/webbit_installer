+(function (window, webduino) {

  'use strict';

  window.getButton = function (board, pin) {
    return new webduino.module.Button(board, board.getDigitalPin(pin));
  }

}(window, window.webduino));
