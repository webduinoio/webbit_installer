# webduino-module-dht

Webduino Module for DHT.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-module-dht.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
