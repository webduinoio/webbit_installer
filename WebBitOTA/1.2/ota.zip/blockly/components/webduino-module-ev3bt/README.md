# webduino-module-ev3bt

Webduino Module for EV3BT.


## Installation

```shell
bower install https://github.com/webduinoio/webduino-module-ev3bt.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
