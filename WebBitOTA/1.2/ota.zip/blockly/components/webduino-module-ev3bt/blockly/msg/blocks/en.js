// LEGO ev3
Blockly.Msg.WEBDUINO_EV3BT = "Use Bluetooth Connect to LEGO EV3 , Rx pin ";
Blockly.Msg.WEBDUINO_EV3BT_FROM = "set ";
Blockly.Msg.WEBDUINO_EV3BT_TX = "  Tx pin ";
Blockly.Msg.WEBDUINO_EV3BT_SEND_TITLE = "Tpye , MsgTitle:";
Blockly.Msg.WEBDUINO_EV3BT_RECV_TITLE = "receive Message , MsgTitle:";
Blockly.Msg.WEBDUINO_EV3BT_SEND_TEXT = " MsgContent:";
Blockly.Msg.WEBDUINO_EV3BT_SEND = "send";
Blockly.Msg.WEBDUINO_EV3BT_RUN = "Run";
Blockly.Msg.WEBDUINO_EV3BT_TEXT = "Text";
Blockly.Msg.WEBDUINO_EV3BT_NUM = "Number";
Blockly.Msg.WEBDUINO_EV3BT_LOGIC = "Logic";
Blockly.Msg.WEBDUINO_EV3BT_GET_MSG = "MsgContent";