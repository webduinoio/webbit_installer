// LEGO ev3
Blockly.Msg.WEBDUINO_EV3BT = "使用藍牙連線到樂高 EV3 , 接收腳 ";
Blockly.Msg.WEBDUINO_EV3BT_FROM = "設定";
Blockly.Msg.WEBDUINO_EV3BT_TX = "  傳送腳";
Blockly.Msg.WEBDUINO_EV3BT_SEND_TITLE = "格式，傳送訊息標題為";
Blockly.Msg.WEBDUINO_EV3BT_SEND_TEXT = "，訊息內容為";
Blockly.Msg.WEBDUINO_EV3BT_RECV_TITLE = "接收訊息內容 , 訊息標題為";
Blockly.Msg.WEBDUINO_EV3BT_SEND = "傳送";
Blockly.Msg.WEBDUINO_EV3BT_RUN = "執行";
Blockly.Msg.WEBDUINO_EV3BT_TEXT = "文字";
Blockly.Msg.WEBDUINO_EV3BT_NUM = "數字";
Blockly.Msg.WEBDUINO_EV3BT_LOGIC = "邏輯";
Blockly.Msg.WEBDUINO_EV3BT_GET_MSG = "訊息內容";