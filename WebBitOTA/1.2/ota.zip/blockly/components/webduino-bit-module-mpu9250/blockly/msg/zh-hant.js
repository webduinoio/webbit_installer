MSG.catMPU9250 = "九軸感測器";
