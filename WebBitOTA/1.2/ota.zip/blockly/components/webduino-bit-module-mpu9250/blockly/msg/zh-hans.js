MSG.catMPU9250 = "九轴感测器";
