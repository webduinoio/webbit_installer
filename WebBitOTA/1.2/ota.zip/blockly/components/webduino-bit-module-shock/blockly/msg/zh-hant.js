MSG.catShock = "震動開關";
