MSG.catShock = "Shake Switch";
