Blockly.Msg.WEBDUINO_SHOCK_NEW = "震动开关，脚位";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_WHEN = "当";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_WAS = "状态为";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_TO = "时";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_DO = "执行";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_HIGH = "通电";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_LOW = "断电";
