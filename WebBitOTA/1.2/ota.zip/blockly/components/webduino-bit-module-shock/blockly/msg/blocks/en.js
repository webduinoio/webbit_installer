Blockly.Msg.WEBDUINO_SHOCK_NEW = "Shock switch, Pin:";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_WHEN = "When";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_WAS = "is";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_TO = "";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_DO = "Do";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_HIGH = "Short Circuit";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_LOW = "Open Circuit";
