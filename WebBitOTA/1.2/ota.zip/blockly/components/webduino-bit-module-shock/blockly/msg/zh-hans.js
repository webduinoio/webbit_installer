MSG.catShock = "震动开关";
