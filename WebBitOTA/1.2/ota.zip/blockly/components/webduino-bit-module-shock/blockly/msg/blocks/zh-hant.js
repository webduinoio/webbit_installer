Blockly.Msg.WEBDUINO_SHOCK_NEW = "震動開關，腳位";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_WHEN = "當";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_WAS = "狀態為";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_TO = "時";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_DO = "執行";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_HIGH = "通電";
Blockly.Msg.WEBDUINO_SHOCK_EVENT_LOW = "斷電";
