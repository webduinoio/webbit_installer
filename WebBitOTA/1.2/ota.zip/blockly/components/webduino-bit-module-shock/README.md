# webduino-bit-module-shock

Block Module for shock senseor of Webduino:bit.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-bit-module-shock.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
