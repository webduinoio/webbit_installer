# webduino-module-wabot

Webduino Module for WABot.


## Installation

```shell
bower install https://github.com/webduinoio/webduino-module-wabot.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
