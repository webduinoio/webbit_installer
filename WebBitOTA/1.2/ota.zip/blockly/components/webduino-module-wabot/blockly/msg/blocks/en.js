// LEGO ev3
Blockly.Msg.WEBDUINO_WABOT = "waBot Robot";
Blockly.Msg.WEBDUINO_WABOT_WALK = "walk ";
