// waBot
Blockly.Msg.WEBDUINO_WABOT = "哇寶機器人";
Blockly.Msg.WEBDUINO_WABOT_WALK = "往前走 ";
