MSG.catBuzzer = "蜂鳴器";
