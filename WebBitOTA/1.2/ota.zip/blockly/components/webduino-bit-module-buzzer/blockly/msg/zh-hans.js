MSG.catBuzzer = "蜂鸣器";
