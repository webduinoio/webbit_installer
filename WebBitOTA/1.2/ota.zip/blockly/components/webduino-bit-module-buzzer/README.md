# webduino-bit-module-buzzer

Module for Webduino:bit Buzzer.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-bit-module-buzzer.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
