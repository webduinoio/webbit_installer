Blockly.Msg.WEBDUINO_SOIL = "土壤湿度侦测，类比脚位：";
Blockly.Msg.WEBDUINO_SOIL_DETECTED = "开始侦测";
Blockly.Msg.WEBDUINO_SOIL_DO = "执行";
Blockly.Msg.WEBDUINO_SOIL_VAL = "侦测的数值";
Blockly.Msg.WEBDUINO_SOIL_STOP = "停止侦测";
