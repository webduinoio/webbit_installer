MSG.catSoil = "Soil Moisture";
