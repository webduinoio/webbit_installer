Blockly.Msg.WEBDUINO_SOIL = "土壤濕度偵測，類比腳位：";
Blockly.Msg.WEBDUINO_SOIL_DETECTED = "開始偵測";
Blockly.Msg.WEBDUINO_SOIL_DO = "執行";
Blockly.Msg.WEBDUINO_SOIL_VAL = "偵測的數值";
Blockly.Msg.WEBDUINO_SOIL_STOP = "停止偵測";
