MSG.catSoil = "土壤濕度偵測";
