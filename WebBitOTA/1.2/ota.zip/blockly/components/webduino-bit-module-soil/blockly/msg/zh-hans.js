MSG.catSoil = "土壤湿度侦测";
