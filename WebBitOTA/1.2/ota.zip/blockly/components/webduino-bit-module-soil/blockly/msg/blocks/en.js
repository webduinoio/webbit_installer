Blockly.Msg.WEBDUINO_SOIL = "Soil, Analog Pin:";
Blockly.Msg.WEBDUINO_SOIL_DETECTED = "Detecting";
Blockly.Msg.WEBDUINO_SOIL_DO = "Do";
Blockly.Msg.WEBDUINO_SOIL_VAL = "Detected Value";
Blockly.Msg.WEBDUINO_SOIL_STOP = "Stop Detecting";
