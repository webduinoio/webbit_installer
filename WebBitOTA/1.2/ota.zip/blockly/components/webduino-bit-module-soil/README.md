# webduino-bit-module-soil

Block Module for Soil Moisture, of Webduino:bit.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-bit-module-soil.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
