MSG.catWS2812 = "全彩点距阵";
