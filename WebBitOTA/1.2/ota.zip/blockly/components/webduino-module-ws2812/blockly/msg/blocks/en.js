// WS2812
Blockly.Msg.WEBDUINO_WS2812_PIN = "RGB LED  Pin:";
Blockly.Msg.WEBDUINO_WS2812_LED = "LED amount";
Blockly.Msg.WEBDUINO_WS2812_LED_SET = "Set Number";
Blockly.Msg.WEBDUINO_WS2812_LED_NUMBER = "";
Blockly.Msg.WEBDUINO_WS2812_LED_UNIT = "";
Blockly.Msg.WEBDUINO_WS2812_LED_COLOR = "of LED's color to";
Blockly.Msg.WEBDUINO_WS2812_DISPLAY = "Display";
Blockly.Msg.WEBDUINO_WS2812_CLEAR = "Clear LED display";
Blockly.Msg.WEBDUINO_WS2812_BRIGHTBESS = "Brightness (0~127)";
Blockly.Msg.WEBDUINO_WS2812_CLOSE = "Close";