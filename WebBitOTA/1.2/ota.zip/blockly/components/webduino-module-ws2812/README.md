#load webduino-module-ws2812 block

localStorage.loaderConfigs="https://webduinoio.github.io/webduino-module-ws2812/blockly.json"
