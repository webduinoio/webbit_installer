Blockly.Msg.WEBDUINO_IRRAW_SEND = '冷气红外线发射，脚位';
Blockly.Msg.WEBDUINO_IRRAW_RECV = '冷气红外线接收，脚位';
Blockly.Msg.WEBDUINO_IRRAW_LAUNCHCODE = '发射代码 ( 十六进位 )';
Blockly.Msg.WEBDUINO_IRRAW_ON = '开始接收冷气红外线';
Blockly.Msg.WEBDUINO_IRRAW_CODE = '接收的代码';
Blockly.Msg.WEBDUINO_IRRAW_DO = '执行';
