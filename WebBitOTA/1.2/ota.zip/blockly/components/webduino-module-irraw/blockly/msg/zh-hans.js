MSG.catIrRaw = '冷气红外线';
