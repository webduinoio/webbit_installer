MSG.catIrRaw = '冷氣紅外線';
