Blockly.Msg.WEBDUINO_IRRAW_SEND = 'IR Sender, Pin:';
Blockly.Msg.WEBDUINO_IRRAW_RECV = 'IR Receiver, Pin:';
Blockly.Msg.WEBDUINO_IRRAW_LAUNCHCODE = 'Launch Codes (m-16):';
Blockly.Msg.WEBDUINO_IRRAW_ON = 'Start Receiving Raw IR';
Blockly.Msg.WEBDUINO_IRRAW_CODE = 'Received code';
Blockly.Msg.WEBDUINO_IRRAW_DO = 'Do';
