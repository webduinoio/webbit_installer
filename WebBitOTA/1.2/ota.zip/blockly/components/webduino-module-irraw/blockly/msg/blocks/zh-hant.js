Blockly.Msg.WEBDUINO_IRRAW_SEND = '冷氣紅外線發射，腳位';
Blockly.Msg.WEBDUINO_IRRAW_RECV = '冷氣紅外線接收，腳位';
Blockly.Msg.WEBDUINO_IRRAW_LAUNCHCODE = '發射代碼 ( 十六進位 )';
Blockly.Msg.WEBDUINO_IRRAW_ON = '開始接收冷氣紅外線';
Blockly.Msg.WEBDUINO_IRRAW_CODE = '接收的代碼';
Blockly.Msg.WEBDUINO_IRRAW_DO = '執行';
