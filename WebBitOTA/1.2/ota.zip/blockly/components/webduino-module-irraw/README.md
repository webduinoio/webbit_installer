# webduino-module-irraw

Webduino Module for IrRaw.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-module-irraw.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
