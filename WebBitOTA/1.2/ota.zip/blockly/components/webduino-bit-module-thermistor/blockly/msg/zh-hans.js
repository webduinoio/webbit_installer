MSG.catThermistor = "热敏电阻";
