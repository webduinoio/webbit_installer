MSG.catThermistor = "熱敏電阻";
