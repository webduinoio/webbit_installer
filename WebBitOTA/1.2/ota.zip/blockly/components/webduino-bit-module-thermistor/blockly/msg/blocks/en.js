Blockly.Msg.WEBDUINO_THERMISTOR = "Thermistor";
Blockly.Msg.WEBDUINO_THERMISTOR_DETECTED = "When Detecting";
Blockly.Msg.WEBDUINO_THERMISTOR_DO = "Do";
Blockly.Msg.WEBDUINO_THERMISTOR_PIN = "Thermistor Pin";  
Blockly.Msg.WEBDUINO_THERMISTOR_VAL = "Current Temperature";
Blockly.Msg.WEBDUINO_THERMISTOR_STOP = "Stop Detecting";
