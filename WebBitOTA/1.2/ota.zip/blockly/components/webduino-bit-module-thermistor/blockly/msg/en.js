MSG.catThermistor = "Thermistor";
