// LoRa
Blockly.Msg.WEBDUINO_LORA_SEND_STRING = "Send String";
Blockly.Msg.WEBDUINO_LORA_SUCCESS_CALLBACK = "After Successed, Do";
Blockly.Msg.WEBDUINO_LORA_FAIL_CALLBACK = "After Failed, Do";
Blockly.Msg.WEBDUINO_LORA_RECEIVE_CALLBACK = "After Receiving String, Do";
Blockly.Msg.WEBDUINO_LORA_RECEIVED_STRING = "Received String";