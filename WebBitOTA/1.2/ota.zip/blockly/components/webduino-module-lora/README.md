# webduino-module-lora

Webduino Module for LoRa.

## Installation

```
bower install https://github.com/webduinoio/webduino-module-lora.git
```

## License

This project is licensed under the MIT license, see LICENSE for more information.