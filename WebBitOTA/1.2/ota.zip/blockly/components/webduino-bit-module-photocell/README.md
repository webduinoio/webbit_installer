# webduino-bit-module-photocell

Module for Webduino:bit Photocell.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-bit-module-photocell.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
