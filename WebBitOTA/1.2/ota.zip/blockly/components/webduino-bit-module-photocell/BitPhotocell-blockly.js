+(function (window, webduino) {

  'use strict';
  
  window.getPhotocell = function (board, analogpin) {
    return new webduino.module.Photocell(board, analogpin);
  }

}(window, window.webduino));
