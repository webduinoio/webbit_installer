MSG.catPhotocell = "Photocell";
