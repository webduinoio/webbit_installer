MSG.catPhotocell = "光敏感測器";
