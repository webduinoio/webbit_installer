MSG.catPhotocell = "光敏感测器";
