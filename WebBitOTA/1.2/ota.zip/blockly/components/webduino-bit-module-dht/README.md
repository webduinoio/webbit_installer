# webduino-bit-module-dht

Block Module for DHT11, of Webduino:bit.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-bit-module-dht.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.
