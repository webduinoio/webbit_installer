MSG.catLedMatrix = "全彩點矩陣";
