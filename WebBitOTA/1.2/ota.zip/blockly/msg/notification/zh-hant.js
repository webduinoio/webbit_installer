MSG.notification_title = "Webduino Bit 更新訊息";
MSG.notification_close = "關閉提示";
MSG.notification_remind = "有更新再提醒我";
