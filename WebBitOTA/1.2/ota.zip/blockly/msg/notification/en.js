MSG.notification_title = "Webduino Bit Changelog";
MSG.notification_close = "Close";
MSG.notification_remind = "Remind me of future updates";