Blockly.Msg.LINE_V1 = 'Value 1 :';
Blockly.Msg.LINE_V2 = 'Value 2 :';
Blockly.Msg.LINE_V3 = 'Value 3 :';
Blockly.Msg.LINE_MSG = 'Message :';
Blockly.Msg.LINE_STKVER = 'Sticker STKVER';
Blockly.Msg.LINE_STKID = ' STKID';