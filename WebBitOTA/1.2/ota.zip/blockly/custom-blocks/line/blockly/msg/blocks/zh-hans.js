Blockly.Msg.LINE_V1 = '值 1 :';
Blockly.Msg.LINE_V2 = '值 2 :';
Blockly.Msg.LINE_V3 = '值 3 :';
Blockly.Msg.LINE_MSG = '讯息 :';
Blockly.Msg.LINE_STKVER = '表情贴图主题';
Blockly.Msg.LINE_STKID = ' 贴图代号';