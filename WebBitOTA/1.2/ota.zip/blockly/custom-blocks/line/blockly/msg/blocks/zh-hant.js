Blockly.Msg.LINE_V1 = '值 1 :';
Blockly.Msg.LINE_V2 = '值 2 :';
Blockly.Msg.LINE_V3 = '值 3 :';
Blockly.Msg.LINE_MSG = '訊息 :';
Blockly.Msg.LINE_STKVER = '表情主題';
Blockly.Msg.LINE_STKID = ' 表情代號';