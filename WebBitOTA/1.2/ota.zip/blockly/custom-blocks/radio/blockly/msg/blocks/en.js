Blockly.Msg.WEBDUINO_BROADCAST_WHEN_RECEIVE_MESSAGE = "When Receive Broadcast Message from Channel";
Blockly.Msg.WEBDUINO_BROADCAST_WHEN_FROM_CHANNEL = "";
Blockly.Msg.WEBDUINO_BROADCAST_DO = "Do";
Blockly.Msg.WEBDUINO_BROADCAST_SEND_MESSAGE = "Send Broadcast Message";
Blockly.Msg.WEBDUINO_BROADCAST_TO_CHANNEL = "to Channel";
Blockly.Msg.WEBDUINO_BROADCAST_RECEIVED_MESSAGE = "Received Broadcast Message";
