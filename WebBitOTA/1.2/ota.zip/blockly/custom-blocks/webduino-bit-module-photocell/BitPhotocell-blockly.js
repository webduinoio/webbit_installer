+(function (window, webduino) {

  'use strict';

  window.getPhotocell = (board, analogpin) => {
    const photocell = new webduino.module.Photocell(board, analogpin);

    photocell.measure((val) => {
      photocell.detectedVal = val;
    });
    return photocell;
  }

}(window, window.webduino));
