Blockly.Msg.WEBDUINO_PHOTOCELL = "Photocell";
Blockly.Msg.WEBDUINO_PHOTOCELL_UPPER_LEFT = "Upper left";
Blockly.Msg.WEBDUINO_PHOTOCELL_UPPER_RIGHT = "Upper right";
Blockly.Msg.WEBDUINO_PHOTOCELL_DETECTED = "Detecting";
Blockly.Msg.WEBDUINO_PHOTOCELL_PIN = "Photocell Pin";
Blockly.Msg.WEBDUINO_PHOTOCELL_DO = "Do";
Blockly.Msg.WEBDUINO_PHOTOCELL_VAL = "Detected value";
Blockly.Msg.WEBDUINO_PHOTOCELL_STOP = "Stop Detecting";
