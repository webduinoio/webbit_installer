MSG.catPhotocell = "光敏(可变)电阻";
