MSG.catPhotocell = "Photocell/Potentiometer";
