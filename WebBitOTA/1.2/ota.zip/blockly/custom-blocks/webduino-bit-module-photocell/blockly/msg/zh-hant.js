MSG.catPhotocell = "光敏(可變)電阻";
